// --- 1. Your Game Directory (Manifest) ---
const myGames = [
    { 
        title: "Epic Quest", 
        url: "games/quest.html", 
        thumb: "thumbs/quest.png" 
    },
    { 
        title: "Lost in Space", 
        url: "games/space.html" 
    },
    { 
        title: "Cat Simulator", 
        url: "games/cat.html", 
        thumb: "thumbs/cat.gif" 
    }
];

const gallery = document.getElementById('gallery');
const player = document.getElementById('game-player');
const frame = document.getElementById('bitsy-frame');
const galleryGrid = document.getElementById('game-grid');

// --- 2. Build the Gallery Automatically ---
function buildGallery() {
    myGames.forEach(game => {
        const card = document.createElement('div');
        card.className = 'card';
        card.onclick = () => loadGame(game.url);

        if (game.thumb) {
            const img = document.createElement('img');
            img.src = game.thumb;
            img.alt = `${game.title} thumbnail`;
            
            // If image fails to load (e.g. thumb doesn't exist yet), replace with placeholder
            img.onerror = function() {
                this.replaceWith(createPlaceholder());
            };
            card.appendChild(img);
        } else {
            card.appendChild(createPlaceholder());
        }

        const title = document.createElement('p');
        title.innerText = game.title;
        card.appendChild(title);

        galleryGrid.appendChild(card);
    });
}

function createPlaceholder() {
    const placeholder = document.createElement('div');
    placeholder.className = 'no-thumb';
    placeholder.innerHTML = `
        <svg viewBox="0 0 24 24" width="64" height="64" stroke="currentColor" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2" y="6" width="20" height="12" rx="2" ry="2"></rect>
            <path d="M6 12h4"></path>
            <path d="M8 10v4"></path>
            <line x1="15" y1="13" x2="15.01" y2="13" stroke-width="3"></line>
            <line x1="18" y1="11" x2="18.01" y2="11" stroke-width="3"></line>
        </svg>
    `;
    return placeholder;
}

buildGallery();

// --- 3. View Management ---
function loadGame(url) {
    frame.src = url;
    gallery.classList.add('hidden');
    player.classList.remove('hidden');
}

function closeGame() {
    frame.src = ""; // Stop the game audio/logic
    player.classList.add('hidden');
    gallery.classList.remove('hidden');
}

// --- 4. Controls / Input Injection ---
function sendKeyEvent(type, key, keyCode) {
    if (!frame.contentWindow) return;

    const event = new KeyboardEvent(type, {
        key: key,
        code: key,
        keyCode: keyCode,
        which: keyCode,
        bubbles: true,
        cancelable: true
    });
    
    frame.contentWindow.document.dispatchEvent(event);
    frame.contentWindow.dispatchEvent(event);
}

const keys = {
    'up': { key: 'ArrowUp', code: 38 },
    'down': { key: 'ArrowDown', code: 40 },
    'left': { key: 'ArrowLeft', code: 37 },
    'right': { key: 'ArrowRight', code: 39 }
};

Object.keys(keys).forEach(id => {
    const btn = document.getElementById(id);
    const keyInfo = keys[id];

    const pressKey = (e) => {
        if (e.cancelable) e.preventDefault();
        btn.classList.add('active');
        sendKeyEvent('keydown', keyInfo.key, keyInfo.code);
    };

    const releaseKey = (e) => {
        if (e.cancelable) e.preventDefault();
        btn.classList.remove('active');
        sendKeyEvent('keyup', keyInfo.key, keyInfo.code);
    };

    // Touch Events
    btn.addEventListener('touchstart', pressKey, { passive: false });
    btn.addEventListener('touchend', releaseKey, { passive: false });
    btn.addEventListener('touchcancel', releaseKey, { passive: false });

    // Mouse Events
    btn.addEventListener('mousedown', pressKey);
    btn.addEventListener('mouseup', releaseKey);
    btn.addEventListener('mouseleave', releaseKey);
});

// --- 5. Physical Keyboard Support ---
const keyboardMap = {
    'ArrowUp': 'up',
    'w': 'up',
    'W': 'up',
    'ArrowDown': 'down',
    's': 'down',
    'S': 'down',
    'ArrowLeft': 'left',
    'a': 'left',
    'A': 'left',
    'ArrowRight': 'right',
    'd': 'right',
    'D': 'right'
};

window.addEventListener('keydown', (e) => {
    if (player.classList.contains('hidden')) return;

    const buttonId = keyboardMap[e.key];
    if (buttonId) {
        e.preventDefault(); 
        const btn = document.getElementById(buttonId);
        if (!btn.classList.contains('active')) {
            btn.classList.add('active'); 
            sendKeyEvent('keydown', keys[buttonId].key, keys[buttonId].code); 
        }
    }
});

window.addEventListener('keyup', (e) => {
    if (player.classList.contains('hidden')) return;

    const buttonId = keyboardMap[e.key];
    if (buttonId) {
        e.preventDefault();
        const btn = document.getElementById(buttonId);
        btn.classList.remove('active'); 
        sendKeyEvent('keyup', keys[buttonId].key, keys[buttonId].code);
    }
});
